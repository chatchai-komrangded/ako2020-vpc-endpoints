/* REQUEST RECEIVED:
{
    "RequestType": "Create",
    "ServiceToken": "arn:aws:lambda:us-west-2:503395950200:function:customresourcewalkthrough-AMIInfoFunction-1GIKWDAYIOTLL",
    "ResponseURL": "https://cloudformation-custom-resource-response-uswest2.s3-us-west-2.amazonaws.com/arn%3Aaws%3Acloudformation%3Aus-west-2%3A503395950200%3Astack/customresourcewalkthrough/6537a860-00d2-11ea-9b37-02578391ed14%7CAMIInfo%7Cacecece9-2056-46d7-a551-43dc63bc051a?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20191106T201911Z&X-Amz-SignedHeaders=host&X-Amz-Expires=7200&X-Amz-Credential=AKIA54RCMT6SCBCEMPG4%2F20191106%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Signature=0ef5486a8b24f033a160bafd1c2f8a75666ca269df03eaa5d4bc8fff33144340",
    "StackId": "arn:aws:cloudformation:us-west-2:503395950200:stack/customresourcewalkthrough/6537a860-00d2-11ea-9b37-02578391ed14",
    "RequestId": "acecece9-2056-46d7-a551-43dc63bc051a",
    "LogicalResourceId": "AMIInfo",
    "ResourceType": "Custom::AMIInfo",
    "ResourceProperties": {
        "ServiceToken": "arn:aws:lambda:us-west-2:503395950200:function:customresourcewalkthrough-AMIInfoFunction-1GIKWDAYIOTLL",
        "Architecture": "PV64",
        "Region": "us-west-2"
    }
}
*/

/*
{
    "RequestType": "Create",
    "ServiceToken": "arn:aws:lambda:us-west-2:503395950200:function:test2-keypairFunction-1O6LK32I10KRY",
    "ResponseURL": "https://cloudformation-custom-resource-response-uswest2.s3-us-west-2.amazonaws.com/arn%3Aaws%3Acloudformation%3Aus-west-2%3A503395950200%3Astack/test2/86ae1c90-00f0-11ea-99e4-064751363480%7Ckeypair%7Cc760998c-cb3d-4aec-a352-72e0d8e03b3d?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20191106T235304Z&X-Amz-SignedHeaders=host&X-Amz-Expires=7200&X-Amz-Credential=AKIA54RCMT6SCBCEMPG4%2F20191106%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Signature=6081436d76ff6427e60a79befa00dac65dee84ac91a87b8b8b8ec060348d1ee2",
    "StackId": "arn:aws:cloudformation:us-west-2:503395950200:stack/test2/86ae1c90-00f0-11ea-99e4-064751363480",
    "RequestId": "c760998c-cb3d-4aec-a352-72e0d8e03b3d",
    "LogicalResourceId": "keypair",
    "ResourceType": "Custom::keypair",
    "ResourceProperties": {
        "ServiceToken": "arn:aws:lambda:us-west-2:503395950200:function:test2-keypairFunction-1O6LK32I10KRY",
        "keypairName": "test2",
        "Region": "us-west-2"
    }
}
*/


//load the sdk 
var AWS = require('aws-sdk');
// Set the region 
AWS.config.update({region: 'us-west-2'});
//AWS.config.update({region: process.env.AWS_REGION });  //test in future in another region
// Create EC2 service object
var ec2 = new AWS.EC2({apiVersion: '2016-11-15'});
// Create a Secrets Manager client
var ssm = new AWS.SSM();


exports.handler = function(event, context) {
 
    console.log("REQUEST RECEIVED:\n" + JSON.stringify(event));
     
    var responseStatus = "FAILED";
    var responseData = {};
    
    var params = { KeyName: event.ResourceProperties.keypairName }; //name keypair based on parameter sent in calling event
    
    // For Delete requests, ec2.deleteKeyPair 
    if (event.RequestType == "Delete") {
        //delete key 
        ec2.deleteKeyPair(params, function(err, data) {
            if (err) {
                responseData = {Error: err};
                console.log(responseData.Error + ":\n", err);
                    } 
            else {
                //construct response
                responseData = {keypairName: event.ResourceProperties.keypairName};
                responseStatus = "SUCCESS"
                }
        //delete labsshkey parameter
        var params = { Name: 'labsshkey' }; /* required */
        ssm.deleteParameter(params, function(err, data) {
          if (err) console.log(err, err.stack); // an error occurred
          else     console.log(data);           // successful response
        });
        //send response
        sendResponse(event, context, responseStatus, responseData);
            });
        return;
    } //end delete use case

    // For Create requests, ec2.createKeyPair 
    if (event.RequestType == "Create") {
       //create key
        ec2.createKeyPair(params, function(err, data) {
           if (err) {
              responseData = {Error: err};
              console.log(responseData.Error + ":\n", err);
           } 
           else { 
               //construct response
                responseData = {keypairName: event.ResourceProperties.keypairName};
                responseStatus = "SUCCESS"
                }
        //create labsshkey parameter
        var keymatterforssm = JSON.stringify(data.KeyMaterial).replace(/['"]+/g, '');
        var params = {
          Name: 'labsshkey', /* required */
          Type: 'SecureString', /* required */
          Value: keymatterforssm, /* required */
          Description: 'key value for pem key enabling ssh access to EC2 instances',
          //AllowedPattern: 'STRING_VALUE', //(Optional) A regular expression used to validate the parameter value. 
          //KeyId: 'STRING_VALUE', //The system automatically populates Key ID with your default KMS key.
          Overwrite: true, //false
          //Policies: 'STRING_VALUE', //One or more policies to apply to a parameter. (expiration, etc)
          //Tags: [
          //  {
          //    Key: 'STRING_VALUE', /* required */
          //    Value: 'STRING_VALUE' /* required */
          //  },
            /* more items */
          //],
          Tier: 'Standard' //| Advanced | Intelligent-Tiering
        };
        ssm.putParameter(params, function(err, data) {
          if (err) console.log(err, err.stack); // an error occurred
          else     console.log(data);           // successful response
        }); 
        //send response
        sendResponse(event, context, responseStatus, responseData);
                });
            return;
        } //end create use case
    
   }; //end handler


// Send response to the pre-signed S3 URL 
function sendResponse(event, context, responseStatus, responseData) {
 
    var responseBody = JSON.stringify({
        Status: responseStatus,
        Reason: "See the details in CloudWatch Log Stream: " + context.logStreamName,
        PhysicalResourceId: context.logStreamName,
        StackId: event.StackId,
        RequestId: event.RequestId,
        LogicalResourceId: event.LogicalResourceId,
        Data: responseData
    });
 
    console.log("RESPONSE BODY:\n", responseBody);
 
    var https = require("https");
    var url = require("url");
 
    var parsedUrl = url.parse(event.ResponseURL);
    var options = {
        hostname: parsedUrl.hostname,
        port: 443,
        path: parsedUrl.path,
        method: "PUT",
        headers: {
            "content-type": "",
            "content-length": responseBody.length
        }
    };
 
    console.log("SENDING RESPONSE...\n");
 
    var request = https.request(options, function(response) {
        console.log("STATUS: " + response.statusCode);
        console.log("HEADERS: " + JSON.stringify(response.headers));
        // Tell AWS Lambda that the function execution is done  
        context.done();
    });
 
    request.on("error", function(error) {
        console.log("sendResponse Error:" + error);
        // Tell AWS Lambda that the function execution is done  
        context.done();
    });
  
    // write data to request body
    request.write(responseBody);
    request.end();
}

/* Send KeyName (without .pem extension) back to the CloudFormation stack so it can be used with the KeyName attributes when EC2 instances are created.
/* RESPONSE BODY:
{
    "Status": "SUCCESS",
    "Reason": "See the details in CloudWatch Log Stream: 2019/11/06/[$LATEST]0a32a2e472014a91827a7be39ea523f9",
    "PhysicalResourceId": "2019/11/06/[$LATEST]0a32a2e472014a91827a7be39ea523f9",
    "StackId": "arn:aws:cloudformation:us-west-2:503395950200:stack/customresourcewalkthrough/6537a860-00d2-11ea-9b37-02578391ed14",
    "RequestId": "acecece9-2056-46d7-a551-43dc63bc051a",
    "LogicalResourceId": "AMIInfo",
    "Data": {
        "Id": "ami-07b629741676653b1"
    }
}
*/